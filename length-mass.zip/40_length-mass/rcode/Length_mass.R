setwd("/Users/nakagawahikaru/Desktop/研究/Rex/40_魚類length-mass")

library(ggplot2)
library(dplyr)
library(tidyr)
library(ggplot2)
library(scales)

data01<-read.csv(file(paste0(getwd(),"/rawdata/Length_mass.csv"),encoding="UTF8"),header=TRUE,sep=",")  #
data02<-read.csv(file(paste0(getwd(),"/rawdata/Taxa.csv"),encoding="UTF8"),header=TRUE,sep=",")  #

data01<-data01[data01$Category=="Fish" & complete.cases(data01$Dry_weight),]
data01$Taxon[data01$Taxon=="Misgurnus anguillicaudatus"]<-"Misgurnus sp."
data01$Wet_weight<-ifelse(data01$Wet_weight>=10,round(data01$Wet_weight,1),round(data01$Wet_weight,3))
data01$Dry_weight<-ifelse(data01$Dry_weight>=10,round(data01$Dry_weight,1),round(data01$Dry_weight,3))

data01<-merge(data01,data02,by="Taxon",all.x=TRUE)

table(data01$Taxon[is.na(data01$Order)])

nrow(data01)
length(unique(data01$Taxon))
length(unique(data01$Order))
length(unique(data01$Family))
length(unique(data01$Genus))

data01$Date<-paste(paste0("20",substr(data01$Date,1,2)),substr(data01$Date,3,4),substr(data01$Date,5,6),sep="-")
unique(data01$Site)
data01$River_system<-NA
data01$Longitude<-NA
data01$Latitude<-NA

data01$River_system[data01$Site=="Kushiro"
                    | data01$Site=="Kushiro-Shibecha"
]<-"Kushiro River"
data01$River_system[data01$Site=="Charo"
]<-"Charo River"
data01$River_system[data01$Site=="Shoro"
]<-"Shoro River"
data01$River_system[data01$Site=="Kiso"
                    | data01$Site=="Kiso-Shinsakai"
                    | data01$Site=="Kiso-Umakai"
                    | data01$Site=="Kiso-south"
                    | data01$Site=="Kuwana"
]<-"Kiso River"
data01$River_system[data01$Site=="Shinbori"
                    | data01$Site=="Seki"
]<-"Nagara River"
data01$River_system[data01$Site=="Ibi"
                    | data01$Site=="Ibi-Hijie"
                    | data01$Site=="Ibi-Makita"
]<-"Ibi River"
data01$River_system[data01$Site=="Yura_Ashiu"
                    | data01$Site=="Yura-Ashiu"
                    | data01$Site=="Yura-Kanzaki"
]<-"Yura River"
data01$River_system[data01$Site=="Biwa"
                    | data01$Site=="Biwa-Mano"
]<-"Yodo River"
data01$River_system[data01$Site=="Ichinomiya"
]<-"Nikko River"
data01$River_system[data01$Site=="Gojo"
]<-"Gojo River"
data01$River_system[data01$Site=="Shounai"
]<-"Shounai River"
data01$River_system[data01$Site=="Asahi-Tajiko"
                    | data01$Site=="Asahi"
]<-"Asahi River"
data01$River_system[data01$Site=="Ara-Koma"
]<-"Ara River"
data01$River_system[data01$Site=="Isumi-Ochiai"
]<-"Isumi River"
data01$River_system[data01$Site=="Yamato-Nara"
]<-"Yamato River"
data01$River_system[data01$Site=="Arita"
]<-"Arita River"

table(data01$Site[is.na(data01$River_system)])


data01$Longitude[data01$Site=="Kushiro"]<-144.608864
data01$Longitude[data01$Site=="Kushiro-Shibecha"]<-144.652635
data01$Longitude[data01$Site=="Charo"]<-144.057943
data01$Longitude[data01$Site=="Shoro"]<-144.137172
data01$Longitude[data01$Site=="Kiso"]<-136.805972
data01$Longitude[data01$Site=="Kiso-Shinsakai"]<-136.806376
data01$Longitude[data01$Site=="Kiso-Umakai"]<-136.686561
data01$Longitude[data01$Site=="Kiso-south"]<-136.798513
data01$Longitude[data01$Site=="Kuwana"]<-136.738232
data01$Longitude[data01$Site=="Shinbori"]<-136.71875890860713
data01$Longitude[data01$Site=="Seki"]<-136.8791440997882
data01$Longitude[data01$Site=="Ibi"]<-136.69893825339244
data01$Longitude[data01$Site=="Ibi-Hijie"]<-136.635706
data01$Longitude[data01$Site=="Ibi-Makita"]<-136.59560334856593
data01$Longitude[data01$Site=="Yura_Ashiu"
                    | data01$Site=="Yura-Ashiu"]<-135.721569
data01$Longitude[data01$Site=="Yura-Kanzaki"]<-135.290186
data01$Longitude[data01$Site=="Biwa"]<-136.045519
data01$Longitude[data01$Site=="Biwa-Mano"]<-135.909795
data01$Longitude[data01$Site=="Ichinomiya"]<-136.805295
data01$Longitude[data01$Site=="Gojo"]<-137.014641
data01$Longitude[data01$Site=="Shounai"]<-136.91218644399387
data01$Longitude[data01$Site=="Asahi-Tajiko"]<-133.901361
data01$Longitude[data01$Site=="Asahi"]<-133.690972
data01$Longitude[data01$Site=="Ara-Koma"]<-139.3351298749415
data01$Longitude[data01$Site=="Isumi-Ochiai"]<-140.32465846573493
data01$Longitude[data01$Site=="Yamato-Nara"]<-135.788212
data01$Longitude[data01$Site=="Arita"]<-135.150839

data01$Latitude[data01$Site=="Kushiro"]<-43.308274
data01$Latitude[data01$Site=="Kushiro-Shibecha"]<-43.367355
data01$Latitude[data01$Site=="Charo"]<-42.975893
data01$Latitude[data01$Site=="Shoro"]<-42.983218
data01$Latitude[data01$Site=="Kiso"]<-35.368095
data01$Latitude[data01$Site=="Kiso-Shinsakai"]<-35.372787
data01$Latitude[data01$Site=="Kiso-Umakai"]<-35.253632
data01$Latitude[data01$Site=="Kiso-south"]<-35.361457
data01$Latitude[data01$Site=="Kuwana"]<-35.033640
data01$Latitude[data01$Site=="Shinbori"]<-35.48282971094582
data01$Latitude[data01$Site=="Seki"]<-35.51684966314317
data01$Latitude[data01$Site=="Ibi"]<-35.10936509478487
data01$Latitude[data01$Site=="Ibi-Hijie"]<-35.119498
data01$Latitude[data01$Site=="Ibi-Makita"]<-35.302832756800264
data01$Latitude[data01$Site=="Yura_Ashiu"
                | data01$Site=="Yura-Ashiu"]<-35.306703
data01$Latitude[data01$Site=="Yura-Kanzaki"]<-35.513686
data01$Latitude[data01$Site=="Biwa"]<-35.440600
data01$Latitude[data01$Site=="Biwa-Mano"]<-35.128851
data01$Latitude[data01$Site=="Ichinomiya"]<-35.330459
data01$Latitude[data01$Site=="Gojo"]<-35.346713
data01$Latitude[data01$Site=="Shounai"]<-35.225710872354476
data01$Latitude[data01$Site=="Asahi-Tajiko"]<-34.853028
data01$Latitude[data01$Site=="Asahi"]<-35.079361
data01$Latitude[data01$Site=="Ara-Koma"]<-35.92293264168955
data01$Latitude[data01$Site=="Isumi-Ochiai"]<-35.187747278919275
data01$Latitude[data01$Site=="Yamato-Nara"]<-34.639999
data01$Latitude[data01$Site=="Arita"]<-34.079627

d<-data.frame(
  Date=data01$Date,
  #Site=data01$Site,
  Latitude=round(data01$Latitude,3),
  Longitude=round(data01$Longitude,3),
  River_system=data01$River_system,
  Order=data01$Order,
  Family=data01$Family,
  Genus=data01$Genus,
  Taxon=data01$Taxon,
  ID=c(1:nrow(data01)),
  Standard_length=data01$Body_length,
  Head_length=data01$Head_length,
  Caudal_peduncle_depth=data01$Tail_height,
  Wet_weight=data01$Wet_weight,
  Dry_weight=data01$Dry_weight
              )
names(d)<-c("Date","Latitude","Longitude","River system","Order","Family","Genus","Taxon","ID","Standard length (mm)","Head length (mm)","Caudal peduncle depth (mm)","Wet weight (g)","Dry weight (g)")

write.csv(d,file=paste0(getwd(),"/output/CSV/Table_S1.csv"),row.names=FALSE)

data01<-read.csv(file(paste0(getwd(),"/output/CSV/Table_S1.csv"),encoding="UTF8"),header=TRUE,sep=",")  #
names(data01)<-c("Date","Latitude","Longitude","River_system","Order","Family","Genus","Taxon","ID","Standard_length","Head_length","Caudal_peduncle_depth","Wet_weight","Dry_weight")

t<-table(data01$Taxon)
r<-tapply(data01$Standard_length,data01$Taxon,range)

d<-data.frame(
  Taxon=names(t),
  Order=tapply(data01$Order,data01$Taxon,unique),
  Family=tapply(data01$Family,data01$Taxon,unique),
  Genus=tapply(data01$Genus,data01$Taxon,unique),
  N=c(t),
  Range_SL=sapply(r,function(x)paste(format(x[1],nsmall=1),format(x[2],nsmall=1),sep="-")),
  Determination=""
)

d<-d[order(d$Taxon),]
d<-d[order(d$Family),]
d$Order<-factor(d$Order,levels=unique(data02$Order))
d<-d[order(d$Order),]

names(d)<-c("Taxon","Order","Family","Genus","N","Range of standard length (mm)","Determination")

target_sp<-names(t)[t>=8]

nrow(data01)
length(unique(data01[is.element(data01$Taxon,target_sp),]$Taxon))
length(unique(data01[is.element(data01$Taxon,target_sp),]$Order))
length(unique(data01[is.element(data01$Taxon,target_sp),]$Family))

#SL-DW
result_list<-list()
for(i in 1:length(target_sp)){
  d00<-data01[data01$Taxon==target_sp[i],]
  lm01<-lm(log(Dry_weight)~log(Standard_length),data=d00)
  result_list[[i]]<-data.frame(
    Taxon=target_sp[i],
    a=round(coefficients(lm01),3)[1],
    b=round(coefficients(lm01),3)[2],
    R_square=round(summary(lm01)$r.squared,3))
}

d0<-do.call(rbind,result_list)

names(d0)<-c("Taxon","lna","b","R-square")
d0<-d0[d0$"R-square">=0.8,]
d0$Taxon<-factor(d0$Taxon,levels=unique(data02$Taxon))
d0<-d0[order(d0$Taxon),]

d$Determination<-ifelse(is.element(d$Taxon,d0$Taxon),paste(d$Determination,"SL→DW",sep=""),d$Determination)

write.csv(d0,file=paste0(getwd(),"/output/CSV/Table_2.csv"),row.names=FALSE)

sb<-d0[d0$Taxon=="Niwaella delicata",]
exp(sb$lna+sb$b*log(100))
sb<-d0[d0$Taxon=="Coreoperca kawamebari",]
exp(sb$lna+sb$b*log(100))

#SL-WW
result_list<-list()
for(i in 1:length(target_sp)){
  d00<-data01[data01$Taxon==target_sp[i] & complete.cases(data01$Wet_weight),]
  if(nrow(d00)>0){
    lm01<-lm(log(Wet_weight)~log(Standard_length),data=d00)
    result_list[[i]]<-data.frame(
      Taxon=target_sp[i],
      a=round(coefficients(lm01),3)[1],
      b=round(coefficients(lm01),3)[2],
      R_square=round(summary(lm01)$r.squared,3))}
}

d0<-do.call(rbind,result_list)

names(d0)<-c("Taxon","lna","b","R-square")
d0<-d0[d0$"R-square">=0.8,]
d0$Taxon<-factor(d0$Taxon,levels=unique(data02$Taxon))
d0<-d0[order(d0$Taxon),]

d$Determination<-ifelse(is.element(d$Taxon,d0$Taxon),paste(d$Determination,"SL→WW",sep=", "),d$Determination)

write.csv(d0,file=paste0(getwd(),"/output/CSV/Table_3.csv"),row.names=FALSE)

#HL-DW
result_list<-list()
for(i in 1:length(target_sp)){
  d00<-data01[data01$Taxon==target_sp[i] & complete.cases(data01$Head_length),]
  if(nrow(d00)>0){
    lm01<-lm(log(Dry_weight)~log(Head_length),data=d00)
    result_list[[i]]<-data.frame(
      Taxon=target_sp[i],
      a=round(coefficients(lm01),3)[1],
      b=round(coefficients(lm01),3)[2],
      R_square=round(summary(lm01)$r.squared,3))}
}

d0<-do.call(rbind,result_list)

names(d0)<-c("Taxon","lna","b","R-square")
d0<-d0[d0$"R-square">=0.8,]
d0$Taxon<-factor(d0$Taxon,levels=unique(data02$Taxon))
d0<-d0[order(d0$Taxon),]

d$Determination<-ifelse(is.element(d$Taxon,d0$Taxon),paste(d$Determination,"HL→DW",sep=", "),d$Determination)

write.csv(d0,file=paste0(getwd(),"/output/CSV/Table_4.csv"),row.names=FALSE)

#HL-WW
result_list<-list()
for(i in 1:length(target_sp)){
  d00<-data01[data01$Taxon==target_sp[i] & complete.cases(data01$Head_length),]
  if(nrow(d00)>0){
    lm01<-lm(log(Wet_weight)~log(Head_length),data=d00)
    result_list[[i]]<-data.frame(
      Taxon=target_sp[i],
      a=round(coefficients(lm01),3)[1],
      b=round(coefficients(lm01),3)[2],
      R_square=round(summary(lm01)$r.squared,3))}
}

d0<-do.call(rbind,result_list)

names(d0)<-c("Taxon","lna","b","R-square")
d0<-d0[d0$"R-square">=0.8,]
d0$Taxon<-factor(d0$Taxon,levels=unique(data02$Taxon))
d0<-d0[order(d0$Taxon),]

d$Determination<-ifelse(is.element(d$Taxon,d0$Taxon),paste(d$Determination,"HL→WW",sep=", "),d$Determination)

write.csv(d0,file=paste0(getwd(),"/output/CSV/Table_5.csv"),row.names=FALSE)

#CD-DW
result_list<-list()
for(i in 1:length(target_sp)){
  d00<-data01[data01$Taxon==target_sp[i] & complete.cases(data01$Caudal_peduncle_depth),]
  if(nrow(d00)>0){
    lm01<-lm(log(Dry_weight)~log(Caudal_peduncle_depth),data=d00)
    result_list[[i]]<-data.frame(
      Taxon=target_sp[i],
      a=round(coefficients(lm01),3)[1],
      b=round(coefficients(lm01),3)[2],
      R_square=round(summary(lm01)$r.squared,3))}
}

d0<-do.call(rbind,result_list)

names(d0)<-c("Taxon","lna","b","R-square")
d0<-d0[d0$"R-square">=0.8,]
d0$Taxon<-factor(d0$Taxon,levels=unique(data02$Taxon))
d0<-d0[order(d0$Taxon),]

d$Determination<-ifelse(is.element(d$Taxon,d0$Taxon),paste(d$Determination,"CD→DW",sep=", "),d$Determination)

write.csv(d0,file=paste0(getwd(),"/output/CSV/Table_6.csv"),row.names=FALSE)

#CD-WW
result_list<-list()
for(i in 1:length(target_sp)){
  d00<-data01[data01$Taxon==target_sp[i] & complete.cases(data01$Caudal_peduncle_depth),]
  if(nrow(d00)>0){
    lm01<-lm(log(Wet_weight)~log(Caudal_peduncle_depth),data=d00)
    result_list[[i]]<-data.frame(
      Taxon=target_sp[i],
      a=round(coefficients(lm01),3)[1],
      b=round(coefficients(lm01),3)[2],
      R_square=round(summary(lm01)$r.squared,3))}
}

d0<-do.call(rbind,result_list)

names(d0)<-c("Taxon","lna","b","R-square")
d0<-d0[d0$"R-square">=0.8,]
d0$Taxon<-factor(d0$Taxon,levels=unique(data02$Taxon))
d0<-d0[order(d0$Taxon),]

d$Determination<-ifelse(is.element(d$Taxon,d0$Taxon),paste(d$Determination,"CD→WW",sep=", "),d$Determination)

write.csv(d0,file=paste0(getwd(),"/output/CSV/Table_7.csv"),row.names=FALSE)

#WW-DW
result_list<-list()
for(i in 1:length(target_sp)){
  d00<-data01[data01$Taxon==target_sp[i] & complete.cases(data01$Wet_weight),]
  if(nrow(d00)>0){
    lm01<-lm(log(Dry_weight)~log(Wet_weight),data=d00)
    result_list[[i]]<-data.frame(
      Taxon=target_sp[i],
      a=round(coefficients(lm01),3)[1],
      b=round(coefficients(lm01),3)[2],
      R_square=round(summary(lm01)$r.squared,3))}
}

d0<-do.call(rbind,result_list)

names(d0)<-c("Taxon","lna","b","R-square")
d0<-d0[d0$"R-square">=0.8,]
d0$Taxon<-factor(d0$Taxon,levels=unique(data02$Taxon))
d0<-d0[order(d0$Taxon),]

d$Determination<-ifelse(is.element(d$Taxon,d0$Taxon),paste(d$Determination,"WW→DW",sep=", "),d$Determination)

write.csv(d0,file=paste0(getwd(),"/output/CSV/Table_8.csv"),row.names=FALSE)

write.csv(d,file=paste0(getwd(),"/output/CSV/Table_1.csv"),row.names=FALSE)

#Higher taxonomic levels
data02<-read.csv(file(paste0(getwd(),"/output/CSV/Table_1.csv"),encoding="UTF8"),header=TRUE,sep=",")  #

#SL-DW
target_sp<-data02$Taxon[grep("SL→DW",data02$Determination)]
d000<-data01[is.element(data01$Taxon,target_sp),]
#All species
Eel<-ifelse(is.element(d000$Taxon,c("Lethenteron sp.","Anguilla japonica","Monopterus albus")),"Eel","non-Eel")

result_list<-list()
for(i in 1:length(unique(Eel))){
  d00<-d000[Eel==unique(Eel)[i],]
  lm01<-lm(log(Dry_weight)~log(Standard_length),data=d00)
  result_list[[i]]<-data.frame(
    Taxon=unique(Eel)[i],
    Order=length(unique(d00$Order)),
    Family=length(unique(d00$Family)),
    Genus=length(unique(d00$Genus)),
    Species=length(unique(d00$Taxon)),
    N=nrow(d00),
    a=round(coefficients(lm01),3)[1],
    b=round(coefficients(lm01),3)[2],
    R_square=round(summary(lm01)$r.squared,3))
}

d0<-do.call(rbind,result_list)

names(d0)<-c("Taxon","Order","Family","Genus","Species","N","lna","b","R-square")
d0<-d0[d0$"R-square">=0.8,]

d<-d0

#Order
result_list<-list()
j<-0
for(i in 1:length(unique(d000$Order))){
  d00<-d000[d000$Order==unique(d000$Order)[i],]
  if(length(unique(d00$Family))>=2){
    j<-j+1
    lm01<-lm(log(Dry_weight)~log(Standard_length),data=d00)
    result_list[[j]]<-data.frame(
      Taxon=unique(d00$Order),
      Order=length(unique(d00$Order)),
      Family=length(unique(d00$Family)),
      Genus=length(unique(d00$Genus)),
      Species=length(unique(d00$Taxon)),
      N=nrow(d00),
      a=round(coefficients(lm01),3)[1],
      b=round(coefficients(lm01),3)[2],
      R_square=round(summary(lm01)$r.squared,3))
  }
}

d0<-do.call(rbind,result_list)

names(d0)<-c("Taxon","Order","Family","Genus","Species","N","lna","b","R-square")
d0<-d0[d0$"R-square">=0.8,]

d<-rbind(d,d0)

#Family
result_list<-list()
j<-0
for(i in 1:length(unique(d000$Family))){
  d00<-d000[d000$Family==unique(d000$Family)[i],]
  if(length(unique(d00$Genus))>=2){
    j<-j+1
    lm01<-lm(log(Dry_weight)~log(Standard_length),data=d00)
    result_list[[j]]<-data.frame(
      Taxon=unique(d00$Family),
      Order=length(unique(d00$Order)),
      Family=length(unique(d00$Family)),
      Genus=length(unique(d00$Genus)),
      Species=length(unique(d00$Taxon)),
      N=nrow(d00),
      a=round(coefficients(lm01),3)[1],
      b=round(coefficients(lm01),3)[2],
      R_square=round(summary(lm01)$r.squared,3))
  }
}

d0<-do.call(rbind,result_list)

names(d0)<-c("Taxon","Order","Family","Genus","Species","N","lna","b","R-square")
d0<-d0[d0$"R-square">=0.8,]

d<-rbind(d,d0)

#Genus
result_list<-list()
j<-0
for(i in 1:length(unique(d000$Genus))){
  d00<-d000[d000$Genus==unique(d000$Genus)[i],]
  if(length(unique(d00$Taxon))>=2){
    j<-j+1
    lm01<-lm(log(Dry_weight)~log(Standard_length),data=d00)
    result_list[[j]]<-data.frame(
      Taxon=paste0(unique(d00$Genus)," spp."),
      Order=length(unique(d00$Order)),
      Family=length(unique(d00$Family)),
      Genus=length(unique(d00$Genus)),
      Species=length(unique(d00$Taxon)),
      N=nrow(d00),
      a=round(coefficients(lm01),3)[1],
      b=round(coefficients(lm01),3)[2],
      R_square=round(summary(lm01)$r.squared,3))
  }
}

d0<-do.call(rbind,result_list)

names(d0)<-c("Taxon","Order","Family","Genus","Species","N","lna","b","R-square")
d0<-d0[d0$"R-square">=0.8,]

d<-rbind(d,d0)

nrow(d)

write.csv(d,file=paste0(getwd(),"/output/CSV/Table_9.csv"),row.names=FALSE)

#SL-WW
target_sp<-data02$Taxon[grep("SL→WW",data02$Determination)]
d000<-data01[is.element(data01$Taxon,target_sp),]
#All species
Eel<-ifelse(is.element(d000$Taxon,c("Lethenteron sp.","Anguilla japonica","Monopterus albus")),"Eel","non-Eel")

result_list<-list()
for(i in 1:length(unique(Eel))){
  d00<-d000[Eel==unique(Eel)[i],]
  lm01<-lm(log(Wet_weight)~log(Standard_length),data=d00)
  result_list[[i]]<-data.frame(
    Taxon=unique(Eel)[i],
    Order=length(unique(d00$Order)),
    Family=length(unique(d00$Family)),
    Genus=length(unique(d00$Genus)),
    Species=length(unique(d00$Taxon)),
    N=nrow(d00),
    a=round(coefficients(lm01),3)[1],
    b=round(coefficients(lm01),3)[2],
    R_square=round(summary(lm01)$r.squared,3))
}

d0<-do.call(rbind,result_list)

names(d0)<-c("Taxon","Order","Family","Genus","Species","N","lna","b","R-square")
d0<-d0[d0$"R-square">=0.8,]

d<-d0

#Order
result_list<-list()
j<-0
for(i in 1:length(unique(d000$Order))){
  d00<-d000[d000$Order==unique(d000$Order)[i],]
  if(length(unique(d00$Family))>=2){
    j<-j+1
    lm01<-lm(log(Wet_weight)~log(Standard_length),data=d00)
    result_list[[j]]<-data.frame(
      Taxon=unique(d00$Order),
      Order=length(unique(d00$Order)),
      Family=length(unique(d00$Family)),
      Genus=length(unique(d00$Genus)),
      Species=length(unique(d00$Taxon)),
      N=nrow(d00),
      a=round(coefficients(lm01),3)[1],
      b=round(coefficients(lm01),3)[2],
      R_square=round(summary(lm01)$r.squared,3))
  }
}

d0<-do.call(rbind,result_list)

names(d0)<-c("Taxon","Order","Family","Genus","Species","N","lna","b","R-square")
d0<-d0[d0$"R-square">=0.8,]

d<-rbind(d,d0)

#Family
result_list<-list()
j<-0
for(i in 1:length(unique(d000$Family))){
  d00<-d000[d000$Family==unique(d000$Family)[i],]
  if(length(unique(d00$Genus))>=2){
    j<-j+1
    lm01<-lm(log(Wet_weight)~log(Standard_length),data=d00)
    result_list[[j]]<-data.frame(
      Taxon=unique(d00$Family),
      Order=length(unique(d00$Order)),
      Family=length(unique(d00$Family)),
      Genus=length(unique(d00$Genus)),
      Species=length(unique(d00$Taxon)),
      N=nrow(d00),
      a=round(coefficients(lm01),3)[1],
      b=round(coefficients(lm01),3)[2],
      R_square=round(summary(lm01)$r.squared,3))
  }
}

d0<-do.call(rbind,result_list)

names(d0)<-c("Taxon","Order","Family","Genus","Species","N","lna","b","R-square")
d0<-d0[d0$"R-square">=0.8,]

d<-rbind(d,d0)

#Genus
result_list<-list()
j<-0
for(i in 1:length(unique(d000$Genus))){
  d00<-d000[d000$Genus==unique(d000$Genus)[i],]
  if(length(unique(d00$Taxon))>=2){
    j<-j+1
    lm01<-lm(log(Wet_weight)~log(Standard_length),data=d00)
    result_list[[j]]<-data.frame(
      Taxon=paste0(unique(d00$Genus)," spp."),
      Order=length(unique(d00$Order)),
      Family=length(unique(d00$Family)),
      Genus=length(unique(d00$Genus)),
      Species=length(unique(d00$Taxon)),
      N=nrow(d00),
      a=round(coefficients(lm01),3)[1],
      b=round(coefficients(lm01),3)[2],
      R_square=round(summary(lm01)$r.squared,3))
  }
}

d0<-do.call(rbind,result_list)

names(d0)<-c("Taxon","Order","Family","Genus","Species","N","lna","b","R-square")
d0<-d0[d0$"R-square">=0.8,]

d<-rbind(d,d0)

nrow(d)

write.csv(d,file=paste0(getwd(),"/output/CSV/Table_10.csv"),row.names=FALSE)

#Figures
Eel<-ifelse(is.element(data01$Taxon,c("Lethenteron sp.","Anguilla japonica","Monopterus albus")),"Eel","non-Eel")
data01$Eel<-Eel

target_sp<-data02$Taxon[grep("SL→DW",data02$Determination)]

d<-data01[is.element(data01$Taxon,target_sp),]

d$Taxon<-factor(d$Taxon,levels=target_sp,ordered=TRUE)

d2<-data.frame(
  Taxon=target_sp,
  Standard_length=tapply(d$Standard_length,d$Taxon,median),
  Dry_weight=tapply(d$Dry_weight,d$Taxon,median)
)

g<-ggplot() +
  stat_smooth(data=d,aes(x=Standard_length,y=Dry_weight*1000,linetype=Eel),colour="#DC143C",method="lm",se=FALSE,linewidth=3) +
  stat_smooth(data=d,aes(x=Standard_length,y=Dry_weight*1000,color=Taxon),method="lm",se=FALSE,linewidth=0.8) +
  #geom_text(data=d2,aes(x=Standard_length,y=Dry_weight*1000,label=Taxon),size=3) +
  scale_color_manual(values=rep("#00BFFF",length(target_sp))) +
  scale_linetype_manual(values=rep("solid",2)) +
  scale_x_log10() +
  scale_y_log10(labels=label_comma(),breaks=c(1,10,100,1000,10000,100000)) +
  labs(x="Standard length (mm)",y="Dry weight (mg)",linetype="") + 
  theme_classic() + 
  theme(aspect.ratio=1,text=element_text(size=14),legend.position="")
ggsave(paste0(getwd(),"/output/PDF/Fig_1.pdf"),g)

data03<-read.csv(file(paste0(getwd(),"/output/CSV/Table_9.csv"),encoding="UTF8"),header=TRUE,sep=",")  #
panel_numbers<-c("(a)","(b)","(c)","(d)","(e)","(f)","(g)","(h)","(i)","(j)",
                 "(k)","(l)","(m)","(n)","(o)","(p)","(q)","(r)","(s)","(t)",
                 "(u)","(v)","(w)","(x)","(y)","(z)","(aa)","(ab)","(ac)","(ad)",
                 "(ae)","(af)","(ag)","(ah)","(ai)")
target_sp<-data02$Taxon[grep("SL→DW",data02$Determination)]
d000<-data01[is.element(data01$Taxon,target_sp),]

target_sp<-data03$Taxon[data03$Order==1 & data03$Family>=2]
d1<-d000[is.element(d000$Order,target_sp),]
d12<-data.frame(
  taxa=tapply(d1$Order,d1$Family,unique),
  taxa2=tapply(d1$Family,d1$Family,unique),
  Standard_length=tapply(d1$Standard_length,d1$Family,median),
  Dry_weight=tapply(d1$Dry_weight,d1$Family,median)
)

target_sp<-data03$Taxon[data03$Family==1 & data03$Genus>=2]
d2<-d000[is.element(d000$Family,target_sp),]
d22<-data.frame(
  taxa=tapply(d2$Family,d2$Genus,unique),
  taxa2=tapply(d2$Genus,d2$Genus,unique),
  Standard_length=tapply(d2$Standard_length,d2$Genus,median),
  Dry_weight=tapply(d2$Dry_weight,d2$Genus,median)
)

target_sp<-data03$Taxon[data03$Genus==1 & data03$Species>=2]
target_sp<-sub(" spp.","",target_sp)
d3<-d000[is.element(d000$Genus,target_sp),]

d3$Genus<-paste0(d3$Genus," spp.")
d32<-data.frame(
  taxa=tapply(d3$Genus,d3$Taxon,unique),
  taxa2=tapply(d3$Taxon,d3$Taxon,unique),
  Standard_length=tapply(d3$Standard_length,d3$Taxon,median),
  Dry_weight=tapply(d3$Dry_weight,d3$Taxon,median)
)

d1$type<-"Order"
d2$type<-"Family"
d3$type<-"Genus"

d12$type<-"Order"
d22$type<-"Family"
d32$type<-"Genus"

d1$taxa<-d1$Order
d2$taxa<-d2$Family
d3$taxa<-d3$Genus

d1$taxa2<-d1$Family
d2$taxa2<-d2$Genus
d3$taxa2<-d3$Taxon

d<-rbind(d1,d2,d3)
d_2<-rbind(d12,d22,d32)

d$taxa<-factor(d$taxa,
               levels=data03$Taxon[!is.element(data03$Taxon,unique(Eel))],
               labels=paste(panel_numbers[1:length(unique(data03$Taxon[!is.element(data03$Taxon,unique(Eel))]))],data03$Taxon[!is.element(data03$Taxon,unique(Eel))],sep=" "),
               ordered=TRUE)
d_2$taxa<-factor(d_2$taxa,
                 levels=data03$Taxon[!is.element(data03$Taxon,unique(Eel))],
                 labels=paste(panel_numbers[1:length(unique(data03$Taxon[!is.element(data03$Taxon,unique(Eel))]))],data03$Taxon[!is.element(data03$Taxon,unique(Eel))],sep=" "),
                 ordered=TRUE)

g<-ggplot() +
  stat_smooth(data=d,aes(x=Standard_length,y=Dry_weight*1000,linetype=taxa),colour="#DC143C",method="lm",se=FALSE,linewidth=2) +
  stat_smooth(data=d,aes(x=Standard_length,y=Dry_weight*1000,color=taxa2),method="lm",se=FALSE,linewidth=1) +
  #geom_text(data=d_2,aes(x=Standard_length,y=Dry_weight*1000,label=taxa2),size=2) +
  facet_wrap(~taxa,scales="fixed") +
  scale_color_manual(values=rep("#00BFFF",length(unique(d$taxa2)))) +
  scale_linetype_manual(values=rep("solid",length(unique(d$taxa)))) +
  scale_x_log10() +
  scale_y_log10(labels=label_comma(),breaks=c(1,10,100,1000,10000,100000)) +
  labs(x="Standard length (mm)",y="Dry weight (mg)") + 
  theme_classic() + 
  theme(aspect.ratio=1,text=element_text(size=8),legend.position="")
ggsave(paste0(getwd(),"/output/PDF/Fig_2.pdf"),g)


g<-ggplot(data=data01) +
  geom_point(aes(x=Standard_length,y=Dry_weight*1000,color=Taxon)) +
  scale_x_log10() +
  scale_y_log10()
g

g<-ggplot(data=data01) +
  geom_point(aes(x=Wet_weight,y=Dry_weight*1000,color=Taxon)) +
  scale_x_log10() +
  scale_y_log10()
g

g<-ggplot(data=data01) +
  geom_point(aes(x=Head_length,y=Dry_weight*1000,color=Taxon)) +
  scale_x_log10() +
  scale_y_log10()
g

g<-ggplot(data=data01) +
  geom_point(aes(x=Caudal_peduncle_depth,y=Dry_weight*1000,color=Taxon)) +
  scale_x_log10() +
  scale_y_log10()
g


hist(data01$Dry_weight/data01$Standard_length)
hist(data01$Dry_weight/data01$Head_length)
hist(data01$Dry_weight/data01$Caudal_peduncle_depth)
hist(data01$Dry_weight/data01$Wet_weight)

data01[data01$Dry_weight/data01$Wet_weight>0.5,]
data01[data01$Dry_weight/data01$Head_length>0.2,]
data01[data01$Dry_weight/data01$Standard_length>0.05,]
data01[data01$Dry_weight/data01$Caudal_peduncle_depth>0.5,]
